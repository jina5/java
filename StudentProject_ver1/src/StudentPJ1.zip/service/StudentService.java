package service;

import java.util.Arrays;
import java.util.Scanner;

import VO.StudentVO;

public class StudentService {

	private StudentVO[] arr; // 클래스가 변수타입이 됨, studentVO를 저장하는 배열 하나 생성
	private int index;

	public StudentService() { // 기본생성자
		arr = new StudentVO[10]; // studentVO 정보를 가진 메모리 주소 저장할수있는 공간 10개 생성
		index = 0;// 인덱스 초기화
	}

	public void registerStudent(Scanner sc) { // 스캐너 매개변수
		
		// 학생정보 입력받아서 저장
		if (index == arr.length) {
			System.out.println("더이상 저장할 공간이 없습니다");
			return;
		}
		System.out.println("학생 정보 등록을 시작합니다...");
		System.out.print("학번 : ");
		String id = sc.nextLine(); // 문자열 입력받기
		System.out.print("이름 : ");
		String name = sc.nextLine();
		System.out.print("전공 : ");
		String major = sc.nextLine();
		System.out.print("학점 : "); // 결합도 높음
		double point = sc.nextDouble(); // 소수 입력받기
		sc.nextLine(); //숫자입력받는 nextDouble이후 엔터를 지운다
		//sc.nextInt() sc.nextDouble() 숫자입력+엔터 - 숫자 데이터 가져간 뒤..
		//ㄴ 엔터 남아있음-> sc.nextLine() 엔터때문에 데이터가 입력되었다고 인식
		//sc.nextLine() 한번 더 넣어서 엔터 가져가도록한다(엔터를 지운다)
		//숫자 입력 받은 뒤에 sc.nextLine() 꼭 넣기!!!
		
		
		// arr에 입력받은 정보를 이용해서 Student 생성하여 배열에 저장
		// index증가
		arr[index] = new StudentVO(id, name, major, point);
		index++;
		System.out.println("학생정보 등록이 완료 되었습니다...");

	}

	//전체 학생정보 조회
	public void printAllStudentInfo() {
		if(index==0) {           //arr에 정보가 하나도 없을 때 index==0
			System.out.println("학생 정보가 없습니다.");
			return; //return안써도 상관없음. 밑에 조건 0<0 거짓이기때문에 실행 안하기때문에 
		}
		for (int i = 0; i < index; i++) {
			arr[i].printStudentInfo(); //메서드에 이미 print가 들어가있기때문에
		}
	}
}
