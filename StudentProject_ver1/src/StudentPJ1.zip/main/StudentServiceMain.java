package main;

import java.util.Scanner;

import service.StudentService;

public class StudentServiceMain {

	public static void main(String[] args) {
		StudentService service = new StudentService();
		Scanner sc = new Scanner(System.in);
		service.registerStudent(sc);
		service.registerStudent(sc); //두번 입력받는다 
		
		service.printAllStudentInfo(); //모든 정보 출력

	}

}
